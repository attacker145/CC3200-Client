/*
 * network_defunes.h
 *
 *  Created on: Nov 21, 2017
 *
 */

#ifndef NETWORK_DEFUNES_H_
#define NETWORK_DEFUNES_H_

//#define POST_REQUEST_URI 		"/post.php"

//#define POST_REQUEST_URI        "/senddata.php"
#define POST_DELETE_SQL			"/delete_SQL.php"
#define DELETE_REQUEST_URI 		"/delete"
#define PUT_REQUEST_URI 		"/put"
#define PUT_DATA            	"PUT request."
#define GET_REQUEST_URI_JSON 	"/get"
#define GET_REQUEST_URI_PAGE	"/data.html"

#define message_brd         "/webapp_pub/CC3200command.php"
//#define POST_REQUEST_URI        "/webapp_pub/pub_post.php"
#define POST_REQUEST_URI        "/webapp_pub/pub_post.php"

//#define HOST_NAME       		"httpbin.org" //"<host name>"
#define HOST_NAME       		"cnktechlabs.com" //"<host name>"
#define HOST_PORT           	80
#define SL_SSL_CA_CERT_FILE_NAME        "/cert/testcacert.der"

#endif /* NETWORK_DEFUNES_H_ */
